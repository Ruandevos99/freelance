const TOKEN_ADDRESS = ''
const TOKEN_ABI = []

export {
  TOKEN_ABI,
  TOKEN_ADDRESS
}
